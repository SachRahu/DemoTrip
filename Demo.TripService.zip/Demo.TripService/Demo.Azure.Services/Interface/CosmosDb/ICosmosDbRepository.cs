﻿using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace Demo.Azure.Services.Interface.CosmosDb
{
    public interface ICosmosDbRepository<T>
    {
        /// <summary>
        /// Saves the item asynchronously
        /// </summary>
        /// <param name="item"></param>
        /// <returns></returns>
        Task<T> SaveItemAsync(T item);

        /// <summary>
        /// Gets the item asynchronously
        /// </summary>
        /// <param name="partitionId">The partitionId identifier</param>
        /// <param name="documentId"></param>
        /// <returns></returns>
        Task<T> GetItemAsync(string partitionId, string documentId);

        /// <summary>
        /// Gets the item asynchronously
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// <returns></returns>
        Task<T> GetItemAsync(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Gets the item asynchronously
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// <param name="maxReturnedDocuments">The maximum returned documents</param>
        /// <param name="enableCrossPartitionQuery">If set to True</param>
        /// <param name="maxDegreeParallellism">The maximum degree of parallelism</param>
        /// <param name="maxBufferedItemCount">The maximum buffered item count</param>
        /// <returns></returns>
        Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate, int maxReturnedDocuments = -1,
           bool enableCrossPartitionQuery = true, int maxDegreeParallellism = -1, int maxBufferedItemCount = -1);

        Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate, Expression<Func<T, object>> orderByPredicated, int skip, int top, int maxReturnedDocuments = -1, bool enableCrossPartitionQuery = true,
            int maxDegreeParallelism = -1, int maxBufferedItemCount = -1);

        Task<int> GetItemCountAsync(Expression<Func<T, bool>> predicate);

        /// <summary>
        /// Deletes the item asynchronously
        /// </summary>
        /// <param name="partitionId">The partition identifier</param>
        /// <param name="documentId">The documentId identifier</param>
        /// <returns></returns>
        Task<T> DeleteItemAsync(string partitionId, string documentId);
    }
}
