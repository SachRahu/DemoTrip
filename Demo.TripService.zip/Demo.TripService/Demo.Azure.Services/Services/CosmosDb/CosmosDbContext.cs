﻿using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using System.Threading.Tasks;

namespace Demo.Azure.Services.Services.CosmosDb
{
    public class CosmosDbContext
    {
        public CosmosDbContext(IDocumentClient client, string dbName)
        {
            Client = client;
            DataBaseName = dbName;
        }

        /// <summary>
        /// Get the name of the database
        /// </summary>
        public string DataBaseName { get; }

        /// <summary>
        /// Get the document client
        /// </summary>
        public IDocumentClient Client { get; }

        /// <summary>
        /// Get the name of the collection
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <returns></returns>
        public string GetCollectionName<T>()
        {
            return typeof(T).Name;
        }

        /// <summary>
        /// Create a database defined by properties in cosmos db client if not exists asynchronously
        /// </summary>
        /// <returns></returns>
        public virtual async Task<Database> CreateDatabaseIfNotExistsAsync()
        {
            return await Client.CreateDatabaseIfNotExistsAsync(new Database
            {
                Id = DataBaseName
            });
        }

        /// <summary>
        /// Delete the database know to the cosmos client asynchronously
        /// </summary>
        /// <returns></returns>
        public async Task<Resource> DeleteDatabaseAsync()
        {
            return await Client.DeleteDatabaseAsync(UriFactory.CreateDatabaseUri(DataBaseName));
        }

        /// <summary>
        /// Create a collection based on the generic type if not exist asynchronously
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="throughput">The collection throughout</param>
        /// <param name="partitionKey"> The collection partition key</param>
        /// <returns></returns>
        public async Task<DocumentCollection> CreateCollectionIfNotExistsAsync<T>(int throughput = 1000, string partitionKey = "id")
        {
            var collectionName = GetCollectionName<T>();

            var documentCollection = new DocumentCollection { Id = collectionName };

            var options = new RequestOptions { OfferThroughput = throughput };

            var collection = await Client.CreateDocumentCollectionIfNotExistsAsync(UriFactory.CreateDatabaseUri(DataBaseName),
                documentCollection, options);

            return collection;

        }
    }
}
