﻿
using Demo.Azure.Services.Interface.CosmosDb;
using Microsoft.Azure.Documents;
using Microsoft.Azure.Documents.Client;
using Microsoft.Azure.Documents.Linq;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Linq.Expressions;
using System.Net;
using System.Threading.Tasks;


namespace Demo.Azure.Services.Services.CosmosDb
{
    public class CosmosDbRepository<T> : ICosmosDbRepository<T>
    {
        private readonly CosmosDbContext dbContext;

        /// <summary>
        /// Initialize a new instance of the CosmosDbRepository
        /// </summary>
        /// <param name="context"></param>
        public CosmosDbRepository(CosmosDbContext context)
        {
            dbContext = context;
        }

        /// <summary>
        /// Save the item asynchronous
        /// </summary>
        /// <param name="item">The Item</param>
        /// <returns></returns>
        public async Task<T> SaveItemAsync(T item)
        {
            var currentItem = await dbContext.Client.UpsertDocumentAsync(UriFactory.CreateDocumentCollectionUri(
                dbContext.DataBaseName,
                dbContext.GetCollectionName<T>()), item);
            return (T)(dynamic)currentItem.Resource;
        }

        /// <summary>
        /// Get the item asynchronous 
        /// </summary>
        /// <param name="partitionId">The partitionId Identifier</param>
        /// <param name="documentId">The documentId Identifier</param>
        /// <returns></returns>
        public async Task<T> GetItemAsync(string partitionId, string documentId)
        {
            try
            {
                return await dbContext.Client.ReadDocumentAsync<T>(
                     UriFactory.CreateDocumentUri(dbContext.DataBaseName, dbContext.GetCollectionName<T>(),
                     documentId), new RequestOptions { PartitionKey = new PartitionKey(partitionId) });
            }
            catch (DocumentClientException ex)
            {
                if (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    return default;
                }

                throw;
            }

        }

        /// <summary>
        /// Get the item asynchronous
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// <returns></returns>
        public async Task<T> GetItemAsync(Expression<Func<T, bool>> predicate)
        {
            try
            {
                var feedOptions = new FeedOptions
                {
                    MaxItemCount = 1,
                    EnableCrossPartitionQuery = true,
                    MaxDegreeOfParallelism = -1,
                    MaxBufferedItemCount = 1
                };

                var query = dbContext.Client.CreateDocumentQuery<T>(
                        UriFactory.CreateDocumentCollectionUri(dbContext.DataBaseName, dbContext.GetCollectionName<T>()),
                        feedOptions)
                    .Where(predicate)
                    .AsDocumentQuery();

                var results = new List<T>();

                while (query.HasMoreResults)
                {
                    var res = await query.ExecuteNextAsync<T>();
                    results.AddRange(res);
                }

                return results.FirstOrDefault();
            }
            catch (DocumentClientException ex)
            {

                if (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    return default;
                }

                throw;
            }
        }

        /// <summary>
        /// Gets the documents asynchronous
        /// </summary>
        /// <param name="predicate">The predicate</param>
        /// <param name="maxReturnedDocuments">The maxReturnedDocuments</param>
        /// <param name="enableCrossPartitionQuery">The enableCrossPartitionQuery</param>
        /// <param name="maxDegreeParallelism">The maxDegreeParallelism</param>
        /// <param name="maxBufferedItemCount">The maxBufferedItemCount</param>
        /// <returns></returns>
        public async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate, int maxReturnedDocuments = -1, bool enableCrossPartitionQuery = true,
           int maxDegreeParallelism = -1, int maxBufferedItemCount = -1)
        {

            try
            {
                var feedOptions = new FeedOptions
                {
                    MaxItemCount = maxReturnedDocuments,
                    EnableCrossPartitionQuery = enableCrossPartitionQuery,
                    MaxDegreeOfParallelism = maxDegreeParallelism,
                    MaxBufferedItemCount = maxBufferedItemCount,

                };

                var query = dbContext.Client.CreateDocumentQuery<T>(
                        UriFactory.CreateDocumentCollectionUri(dbContext.DataBaseName, dbContext.GetCollectionName<T>()),
                        feedOptions)
                    .Where(predicate)
                    .AsDocumentQuery();

                var results = new List<T>();

                while (query.HasMoreResults)
                {
                    var res = await query.ExecuteNextAsync<T>();
                    results.AddRange(res);
                }

                return results;
            }
            catch (DocumentClientException ex)
            {

                if (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    return default(List<T>);
                }

                throw;
            }
        }

        public async Task<IEnumerable<T>> GetItemsAsync(Expression<Func<T, bool>> predicate, Expression<Func<T, object>> orderByPredicated, int skip, int top, int maxReturnedDocuments = -1, bool enableCrossPartitionQuery = true,
            int maxDegreeParallelism = -1, int maxBufferedItemCount = -1)
        {

            try
            {
                var feedOptions = new FeedOptions
                {
                    MaxItemCount = maxReturnedDocuments,
                    EnableCrossPartitionQuery = enableCrossPartitionQuery,
                    MaxDegreeOfParallelism = maxDegreeParallelism,
                    MaxBufferedItemCount = maxBufferedItemCount
                };

                var query = dbContext.Client.CreateDocumentQuery<T>(
                        UriFactory.CreateDocumentCollectionUri(dbContext.DataBaseName, dbContext.GetCollectionName<T>()),
                        feedOptions)
                    .Where(predicate)
                    .OrderByDescending(orderByPredicated)
                    .Skip(skip)
                    .Take(top)
                    .AsDocumentQuery();

                var results = new List<T>();

                while (query.HasMoreResults)
                {
                    var res = await query.ExecuteNextAsync<T>();
                    results.AddRange(res);
                }

                return results;
            }
            catch (DocumentClientException ex)
            {

                if (ex.StatusCode == HttpStatusCode.NotFound)
                {
                    return default(List<T>);
                }

                throw;
            }
        }

        public async Task<int> GetItemCountAsync(Expression<Func<T, bool>> predicate)
        {
            return await dbContext.Client.CreateDocumentQuery<T>(UriFactory.CreateDocumentCollectionUri(dbContext.DataBaseName, dbContext.GetCollectionName<T>()), new FeedOptions
                    {
                        MaxItemCount = -1
                    })
                .Where(predicate)
                .CountAsync();
        }

        
        /// <summary>
        /// Deletes the item asynchronous
        /// </summary>
        /// <param name="partitionId">The partition identifier</param>
        /// <param name="documentId">The document identifier</param>
        /// <returns></returns>
        public async Task<T> DeleteItemAsync(string partitionId, string documentId)
        {
            var resultDoc = await dbContext.Client.DeleteDocumentAsync(
                UriFactory.CreateDocumentUri(dbContext.DataBaseName, dbContext.GetCollectionName<T>(), documentId),
                new RequestOptions { PartitionKey = new PartitionKey(partitionId) });
            return (T)(dynamic)resultDoc.Resource ?? default;
        }
    }
}
