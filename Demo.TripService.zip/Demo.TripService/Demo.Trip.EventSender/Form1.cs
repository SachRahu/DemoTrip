﻿using Demo.TripService.Domain.Models;
using Microsoft.Azure.EventHubs;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Demo.Trip.EventSender
{
    public partial class Form1 : Form
    {
        private static EventHubClient client = null;
        public Form1()
        {
            InitializeComponent();

        }

        /// <summary>
        /// Start sending device event with intervals 
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void btn1_Click(object sender, EventArgs e)
        {
            EventHubIngestionAsync(txtTripId.Text, Convert.ToDouble(txtLat.Text), Convert.ToDouble(txtLongi.Text), Convert.ToDouble(txtSpeed.Text), "Start").Wait();
        }

        /// <summary>
        /// Sendv trip end event
        /// </summary>
        /// <param name="sender">sender</param>
        /// <param name="e">e</param>
        private void btn2_Click(object sender, EventArgs e)
        {
            btn1.Enabled = false;
            btn2.Enabled = false;
            EventHubIngestionAsync(txtTripId.Text, Convert.ToDouble(txtLat.Text), Convert.ToDouble(txtLongi.Text), Convert.ToDouble(txtSpeed.Text), "End").Wait();
                   
        }

        /// <summary>
        /// Push device ebent into to the ebent hub
        /// </summary>
        /// <param name="tripId"></param>
        /// <param name="lat"></param>
        /// <param name="longi"></param>
        /// <param name="speed"></param>
        /// <param name="action"></param>
        /// <returns></returns>
        public static async Task EventHubIngestionAsync(string tripId, double lat, double longi, double speed, string action)
        {
            var connection = new EventHubsConnectionStringBuilder("Endpoint=sb://trip-demo.servicebus.windows.net/;SharedAccessKeyName=managemessagesender;SharedAccessKey=9ENElqOoOoabQaEKviGjbuKAVuXqRpf2bCvb74DpA20=;")
            {
                EntityPath = "tripevent"
            };

            client = EventHubClient.CreateFromConnectionString(connection.ToString());

            var deviceMessage = GetTrip(tripId, lat, longi, speed, action);


            var message = Newtonsoft.Json.JsonConvert.SerializeObject(deviceMessage);
            var eventdata = new EventData(Encoding.UTF8.GetBytes(message));
            await client.SendAsync(eventdata);
        }

        private static Trips GetTrip(string tripId, double lat, double longi, double speed, string action)
        {
            if (action == "Start")
            {
                var trip = new Trips

                {
                    Id = tripId,
                    DeviceType = "GPSTracker",
                    DeviceId = "1234",
                    DeviceEvents = SendDeviceEvent(lat, longi, speed)
                };
                return trip;
            }
            else
            {
                var trip = new Trips

                {
                    Id = tripId,
                    DeviceType = "GPSTracker",
                    DeviceId = "1234",
                    DeviceEvents = SendDeviceEvent(lat, longi, speed),
                    EndLocation = new GeoLocation
                    {
                        Address =new GeoAddress
                        {
                            City="testCity",
                            Country="testCountry",
                            County="testCounty",
                            District="testDistrict",
                            FullAddress="testFull address",
                            State="testState",
                            PostalCode="testPostal Code"
                        },
                        Coordinate = new GeoCoordinate
                        {
                            Latitude =20.30,
                            Longitude =30.45
                        }
                    }
                };
                return trip;
            }

        }

        private static List<DeviceEvent> SendDeviceEvent(double lat, double longi, double speed)
        {
            var list = new List<DeviceEvent>();
            var deviceEvent = new DeviceEvent
            {
                Coordinate = new GeoCoordinate
                {
                    Latitude = lat,
                    Longitude = longi
                },
                DateTime = DateTime.UtcNow,
                Speed = speed
            };

            list.Add(deviceEvent);

            return list;
        }
    }
}
