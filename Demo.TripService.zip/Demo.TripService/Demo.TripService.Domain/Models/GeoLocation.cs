﻿using Newtonsoft.Json;

namespace Demo.TripService.Domain.Models
{
    public class GeoLocation
    {
        [JsonProperty("coordinate")]
        public GeoCoordinate Coordinate { get; set; }
        [JsonProperty("address")]
        public GeoAddress Address { get; set; }
    }
}
