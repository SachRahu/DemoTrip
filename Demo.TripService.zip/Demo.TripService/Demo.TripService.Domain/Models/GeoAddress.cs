﻿
using Newtonsoft.Json;

namespace Demo.TripService.Domain.Models
{
    public class GeoAddress
    {

        [JsonProperty("fullAddress")]
        public string FullAddress { get; set; }

        [JsonProperty("country")]
        public string Country { get; set; }

        [JsonProperty("state")]
        public string State { get; set; }

        [JsonProperty("county")]
        public string County { get; set; }

        [JsonProperty("city")]
        public string City { get; set; }

        [JsonProperty("district")]
        public string District { get; set; }

        [JsonProperty("street")]
        public string Street { get; set; }

        [JsonProperty("postalCode")]
        public string PostalCode { get; set; }
    }
}
