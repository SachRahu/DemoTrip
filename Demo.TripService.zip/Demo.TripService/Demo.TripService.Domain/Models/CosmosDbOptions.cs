﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.TripService.Domain.Models
{
    public class CosmosDbOptions
    {
        public string ConnectionString { get; set; }
        public string DbName { get; set; }
    }
}
