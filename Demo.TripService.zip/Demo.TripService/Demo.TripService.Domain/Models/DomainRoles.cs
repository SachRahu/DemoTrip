﻿using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.TripService.Domain.Models
{
   public class DomainRoles
    {
        /// <summary>
        /// The Expert role ("User").
        /// </summary>
        public const string User = "User";
    }
}
