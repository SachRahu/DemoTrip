﻿using Newtonsoft.Json;

namespace Demo.TripService.Domain.Models
{
    public class GeoCoordinate
    {
        [JsonProperty("latitude")]
        public double Latitude { get; set; }

        [JsonProperty("longitude")]
        public double Longitude { get; set; }
    }
}
