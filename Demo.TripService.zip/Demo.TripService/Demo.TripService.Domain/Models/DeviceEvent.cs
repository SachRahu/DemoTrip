﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.TripService.Domain.Models
{
    public class DeviceEvent
    {
        /// <summary>The UTC date time of the event in ISO 8601 (yyyy-MM-ddTHH:mm:ss.sssZ).</summary>
        [JsonProperty("dateTime")]
        public DateTimeOffset DateTime { get; set; }

        [JsonProperty("speed")]
        public double Speed { get; set; }

        /// <summary>The coordinate of the event.</summary>
        [JsonProperty("coordinate")]
        public GeoCoordinate Coordinate { get; set; }
    }
}
