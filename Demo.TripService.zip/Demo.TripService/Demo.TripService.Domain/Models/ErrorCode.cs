﻿using System;
using System.Collections.Generic;
using System.Net;
using System.Text;

namespace Demo.TripService.Domain.Models
{
    public class ErrorCode
    {
        public static ErrorCode BadRequest = new ErrorCode
        {
            Title = "Bad Request",
            Message = "An issue occurred with this request.",
            Code = (int)HttpStatusCode.BadRequest
        };

        public static ErrorCode NotFound = new ErrorCode
        {
            Title = "Not Found",
            Message = "Not Found",
            Code = (int)HttpStatusCode.NotFound
        };

        public static ErrorCode InternalServerError = new ErrorCode
        {
            Title = "Internal server error",
            Message = "Internal server error",
            Code = (int)HttpStatusCode.InternalServerError
        };

        public static ErrorCode UnAuthorized = new ErrorCode
        {
            Title = "Unauthorized",
            Message = "Unauthorized",
            Code = (int)HttpStatusCode.Unauthorized
        };

        public string Title { get; private set; }
        public string Message { get; private set; }
        public int Code { get; private set; }
    }
}
