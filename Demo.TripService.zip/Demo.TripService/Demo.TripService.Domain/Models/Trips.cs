﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;

namespace Demo.TripService.Domain.Models
{
    public class Trips
    {
        /// <summary>The trip ID.</summary>
        [JsonProperty("id")]
        public string Id { get; set; }

        /// <summary>The UTC start time).</summary>
        [JsonProperty("startDateTime")]
        public DateTimeOffset StartDateTime { get; set; }

        /// <summary>The UTC end time).</summary>
        [JsonProperty("endDateTime")]
        public DateTimeOffset EndDateTime { get; set; }      

        /// <summary>The device type the trip.</summary>
        [JsonProperty("deviceType")]
        public string DeviceType { get; set; }

        /// <summary>The device ID of the trip.</summary>
        [JsonProperty("deviceId")]
        public string DeviceId { get; set; }
      

        /// <summary>The ID of the vehicle that recorded the trip.</summary>
        [JsonProperty("vehicleId")]
        public string VehicleId { get; set; }   

        /// <summary>The trip distance in m.</summary>
        [JsonProperty("distance")]
        public long Distance { get; set; }

        /// <summary>The minimum speed of the trip in m/s.</summary>
        [JsonProperty("minSpeed")]
        public double MinSpeed { get; set; }

        /// <summary>The maximum speed of the trip in m/s.</summary>
        [JsonProperty("maxSpeed")]
        public double MaxSpeed { get; set; }

        /// <summary>The average speed of the trip in m/s.</summary>
        [JsonProperty("averageSpeed")]
        public double AverageSpeed { get; set; }

        /// <summary>The start location of the trip.</summary>
        [JsonProperty("startLocation")]
        public GeoLocation StartLocation { get; set; }

        /// <summary>The end location of the trip.</summary>
        [JsonProperty("endLocation")]
        public GeoLocation EndLocation { get; set; }

        /// <summary>Array of device events of the trip.</summary>
        [JsonProperty("deviceEvents")]
        public List<DeviceEvent> DeviceEvents { get; set; }
    }
}
