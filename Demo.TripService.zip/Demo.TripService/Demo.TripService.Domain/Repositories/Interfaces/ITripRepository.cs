﻿using Demo.TripService.Domain.Models;
using System;
using System.Collections.Generic;
using System.Text;
using System.Threading.Tasks;

namespace Demo.TripService.Domain.Repositories.Interfaces
{
   public interface ITripRepository
    {
        Task<Trips> SaveTrip(Trips trip);

        Task<Trips> GetTrip(string tripId);
    }
}
