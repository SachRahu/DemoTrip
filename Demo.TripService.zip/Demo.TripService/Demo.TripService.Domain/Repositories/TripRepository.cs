﻿using Demo.Azure.Services.Interface.CosmosDb;
using Demo.Azure.Services.Services.CosmosDb;
using Demo.TripService.Domain.Models;
using Demo.TripService.Domain.Repositories.Interfaces;
using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Data.Common;
using System.Text;
using System.Threading.Tasks;

namespace Demo.TripService.Domain.Repositories
{
    public class TripRepository : ITripRepository
    {
        private readonly ICosmosDbRepository<Trips> tripRepository;

        public TripRepository(IOptions<CosmosDbOptions> cosmosDbOptions)
        {
            var connectionPolicy = new ConnectionPolicy
            {
                RetryOptions = new RetryOptions
                {
                    MaxRetryAttemptsOnThrottledRequests = 2,
                    MaxRetryWaitTimeInSeconds = 10
                },
                ConnectionMode = ConnectionMode.Direct,
                ConnectionProtocol = Protocol.Tcp
            };

            var connectionStringBuilder = new DbConnectionStringBuilder
            {
                ConnectionString = cosmosDbOptions.Value.ConnectionString
            };

            connectionStringBuilder.TryGetValue("AccountEndpoint", out var endpointObject);
            connectionStringBuilder.TryGetValue("AccountKey", out var keyObject);
            var endpoint = endpointObject.ToString();
            if (string.IsNullOrEmpty(endpoint))
            {
                throw new Exception("The CosmosDB connection string does not contain any AccountEndpoint.");
            }

            var client = new DocumentClient(new Uri(endpoint), keyObject.ToString());
            var databaseContext = new CosmosDbContext(client, cosmosDbOptions.Value.DbName);

            tripRepository = new CosmosDbRepository<Trips>(databaseContext);
        }

        public async Task<Trips> GetTrip(string tripId)
        {
            return await tripRepository.GetItemAsync(o => o.Id == tripId);
        }

        public async Task<Trips> SaveTrip(Trips trip)
        {
            return await tripRepository.SaveItemAsync(trip);
        }
    }
}
