﻿using AutoFixture;
using Demo.Azure.Services.Services.CosmosDb;
using FluentAssertions;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Text;
using Xunit;

namespace Demo.Azure.Services.Tests.CosmosDb
{
   public class CosmosDbRepositoryTest: IntegrationSpecsTest
    {
        private readonly CosmosDbRepository<Trips> cosmosDbRepository;
        private readonly Fixture fixture;

        public CosmosDbRepositoryTest()
        {
            var cosmosDbContext = new CosmosDbContext(DocumentClient, DatabaseName);
            cosmosDbRepository = new CosmosDbRepository<Trips>(cosmosDbContext);
            fixture = new Fixture();
        }

        [Fact]
        public async void WhenSavetemIsCalled_ItemShouldBeCreated()
        {
            //Arrange
            var item = fixture.Create<Trips>();

            //Act
            var createdItem = await cosmosDbRepository.SaveItemAsync(item);
            var getItem = await cosmosDbRepository.GetItemAsync(item.Id, item.Id);
            await cosmosDbRepository.DeleteItemAsync(item.Id, item.Id);

            //Assert
            createdItem.Should().BeEquivalentTo(item);
            getItem.Should().BeEquivalentTo(item);
        }


        [Fact]
        public async void WhenSavetemIsCalledTwice_ItemShouldBeUpdated()
        {
            //Arrange
            var item = fixture.Create<Trips>();

            //Act
            await cosmosDbRepository.SaveItemAsync(item);
            item.TestProperty = 123456;
            var updatedItem = await cosmosDbRepository.SaveItemAsync(item);
            var getItem = await cosmosDbRepository.GetItemAsync(item.Id, item.Id);
            await cosmosDbRepository.DeleteItemAsync(item.Id, item.Id);

            //Assert
            updatedItem.Should().BeEquivalentTo(item);
            getItem.Should().BeEquivalentTo(item);
        }

        [Fact]
        public async void WhenGetItemsAsyncByPredicate_TripsShouldBeReturned()
        {
            // Arrange
            var item = fixture.Create<Trips>();
            var item2 = fixture.Create<Trips>();
            item2.TestProperty = item.TestProperty;

            // Act
            await cosmosDbRepository.SaveItemAsync(item);
            await cosmosDbRepository.SaveItemAsync(item2);
            var claims = await cosmosDbRepository.GetItemsAsync(c => c.TestProperty == item.TestProperty);
            await cosmosDbRepository.DeleteItemAsync(item.Id, item.Id);
            await cosmosDbRepository.DeleteItemAsync(item2.Id, item2.Id);

            // Assert
            claims.Should().HaveCount(2).And.BeEquivalentTo(new List<Trips> { item, item2 });
        }


        [Fact]
        public async void WhenGetItemAsyncByPredicate_TripsShouldBeReturned()
        {
            // Arrange
            var item = fixture.Create<Trips>();

            // Act
            await cosmosDbRepository.SaveItemAsync(item);
            var actualItem = await cosmosDbRepository.GetItemAsync(c => c.TestProperty == item.TestProperty);
            await cosmosDbRepository.DeleteItemAsync(item.Id, item.Id);

            // Assert
            actualItem.Should().NotBeNull().And.BeEquivalentTo(item);
        }

        [Fact]
        public async void WhenDeleteItemAsync_ItemShouldNotBeReturned()
        {
            //Arrange
            var item = fixture.Create<Trips>();

            //Act
            await cosmosDbRepository.SaveItemAsync(item);
            await cosmosDbRepository.DeleteItemAsync(item.Id, item.Id);
            var actualItem = await cosmosDbRepository.GetItemAsync(item.Id, item.Id);

            //Assert
            actualItem.Should().BeNull();
        }
        private class Trips
        {
            [JsonProperty("id")]
            public string Id { get; set; }

            [JsonProperty("testProperty")]
            public int TestProperty { get; set; }
        }
    }
}
