﻿using Microsoft.Azure.Documents.Client;
using Microsoft.Extensions.Configuration;
using System;

namespace Demo.Azure.Services.Tests.CosmosDb
{
   public class IntegrationSpecsTest
    {
        protected readonly DocumentClient DocumentClient;
        protected readonly string DatabaseName;

        protected IntegrationSpecsTest()
        {
            var config = new ConfigurationBuilder()
                .SetBasePath(AppContext.BaseDirectory)
                .AddJsonFile("appsettings.json", false, true)
                .Build();

            var cosmosDbOptions = config.GetSection("CosmosDbOptions");
            DocumentClient = new DocumentClient(new Uri(cosmosDbOptions["DocumentDbUrl"]), cosmosDbOptions["DocumentDbKey"]);
            DatabaseName = cosmosDbOptions["DocumentDbName"];
        }
    }
}
