﻿using AutoMapper;
using Demo.TripService.API.Controllers;
using Demo.TripService.API.MappingConfigurations;
using Demo.TripService.Domain.Models;
using Demo.TripService.Domain.Repositories.Interfaces;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Moq;
using System.Net;
using System.Threading.Tasks;
using Xunit;
using FluentAssertions;
using AutoFixture;
using System;

namespace Demo.TripService.API.Tests.Controllers
{
   public class TripControllerTest
    {
        private readonly TripController tripController;
        private readonly Mock<ITripRepository> tripRepositoryMock;
        private readonly IMapper mapper;

        public TripControllerTest()
        {           

            var logger = Mock.Of<ILogger<TripController>>();
            tripRepositoryMock = new Mock<ITripRepository>();
            var mapperConfig = new MapperConfiguration(c => { c.AddProfile<AutoMapperProfile>(); });
            var mapper = mapperConfig.CreateMapper();

            tripController = new TripController(logger, tripRepositoryMock.Object,mapper)
            {                
            };
        }

        [Fact]
        public async void WhenTripIsCalledAndTripRepositoryReturnsNull_ThenNotFoundResultShouldBeReturned()
        {
            // Arrange
            tripRepositoryMock.Setup(c => c.GetTrip(It.IsAny<string>()))
                .Returns(Task.FromResult((Trips)null));

            // Act
            var getTripResponse = await tripController.GetTrip("tripId");

            // Assert
            getTripResponse.Result.Should().BeOfType<NotFoundObjectResult>()
                .Which.StatusCode.Should().Be((int)HttpStatusCode.NotFound);
        }

        [Fact]
        public async void WhenGetFraudDetectionIsCalledAndFraudRepository_ReturnsResult()
        {
            // Arrange
            var trip = new Fixture().Create<Trips>();
          
            var tripId = new Fixture().Create<string>();

           
            tripRepositoryMock.Setup(c => c.GetTrip(It.IsAny<string>()))
                .Returns((string tripId) =>
                {
                    trip.Id = tripId;
                    return Task.FromResult(trip);
                });
            

            // Act
            var getTrip = await tripController.GetTrip(tripId);

            // Assert
            var objectResult = getTrip.Result.Should().BeOfType<OkObjectResult>().Subject;
            objectResult.StatusCode.Should().Be((int)HttpStatusCode.OK);
        }

        [Fact]
        public async void WhenGetTripIsCalledAndTripRepositoryThrowsAnException_ThenInternalServerErrorShouldBeReturned()
        {

            var tripId = new Fixture().Create<string>();
            // Arrange
            tripRepositoryMock.Setup(c => c.GetTrip(It.IsAny<string>()))
                .Throws(new Exception());

            // Act
            var getTrip = await tripController.GetTrip(tripId);

            // Assert
            getTrip.Result.Should().BeOfType<ObjectResult>()
                .Which.StatusCode.Should().Be((int)HttpStatusCode.InternalServerError);
        }
    }
}
