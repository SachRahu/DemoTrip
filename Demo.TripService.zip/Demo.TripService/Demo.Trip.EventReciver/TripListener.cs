using Demo.TripService.Domain.Models;
using Demo.TripService.Domain.Repositories.Interfaces;
using Microsoft.Azure.EventHubs;
using Microsoft.Azure.WebJobs;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Demo.Trip.EventReciver
{
    public class TripListener
    {
        private ITripRepository _tripRepository;

        public TripListener(ITripRepository tripRepository)
        {
            _tripRepository = tripRepository;
        }

        /// <summary>
        /// TripListener function read device event from tripevent hub and stoared in database
        /// </summary>
        /// <param name="events">events</param>
        /// <param name="log">log</param>
        /// <returns></returns>
        [FunctionName("TripListener")]
        public async Task Run([EventHubTrigger("tripevent", Connection = "EventHubConnectionString")] EventData[] events, ILogger log)
        { 
            foreach (EventData eventData in events)
            {
                try
                {
                    string messageBody = Encoding.UTF8.GetString(eventData.Body.Array, eventData.Body.Offset, eventData.Body.Count);
                    var message = JsonConvert.DeserializeObject<Trips>(messageBody);
                    log.LogInformation($"C# Event Hub trigger function processed a message: {messageBody}");
                    var result = await _tripRepository.GetTrip(message.Id);
                    if (result == null)

                    {
                        log.LogInformation($" Trip {message.Id} was not found");
                    }

                    result.DeviceEvents.Add(message.DeviceEvents.FirstOrDefault());
                    result.EndLocation = message.EndLocation;
                    result.EndDateTime = DateTime.UtcNow;
                    await _tripRepository.SaveTrip(result);
                    log.LogInformation($"Trip updated successfully for : {message.Id}");
                }
                catch (Exception e)
                {
                    log.LogError(e, "An error has occurred with TripListener");
                }
            }
        }
    }
}
