﻿
using Newtonsoft.Json;

namespace Demo.TripService.API.Models
{
    public class GeoLocationDto
    {
        [JsonProperty("coordinate")]
        public GeoCoordinateDto Coordinate { get; set; }
        [JsonProperty("address")]
        public GeoAddressDto Address { get; set; }
    }
}
