﻿using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.TripService.API.Models
{
    public class TripRequestDto
    {
        /// <summary>The UTC start time).</summary>
        [JsonProperty("startDateTime")]
        public DateTimeOffset StartDateTime { get; set; }
        /// <summary>The ID of the vehicle that recorded the trip.</summary>
        [JsonProperty("vehicleId")]
        public string VehicleId { get; set; }

        /// <summary>The start location of the trip.</summary>
        [JsonProperty("startLocation")]
        public GeoLocationDto StartLocation { get; set; }
    }
}
