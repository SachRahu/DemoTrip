﻿using Newtonsoft.Json;

namespace Demo.TripService.API.Models
{
    public class GeoCoordinateDto
    {
        [JsonProperty("latitude")]
        public double Latitude { get; set; }

        [JsonProperty("longitude")]
        public double Longitude { get; set; }
    }
}
