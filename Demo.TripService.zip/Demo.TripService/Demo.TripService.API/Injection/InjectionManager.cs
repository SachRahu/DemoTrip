﻿using Demo.TripService.Domain.Models;
using Demo.TripService.Domain.Repositories;
using Demo.TripService.Domain.Repositories.Interfaces;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;

namespace ClaimMateService.Api.Injection
{
    public static class InjectionManager
    {
        public static IServiceCollection RepositoryInjector(this IServiceCollection services, IConfiguration configuration)
        {
            var apiManagementKey = configuration.GetValue<string>("IntegrationService:SubscriptionKey");

            services.Configure<CosmosDbOptions>(configuration.GetSection("CosmosDb"));
            services.AddSingleton<ITripRepository, TripRepository>();
            return services;
        }
    }
}