﻿using AutoMapper;
using Demo.TripService.API.Models;
using Demo.TripService.API.Utils;
using Demo.TripService.Domain.Models;
using Demo.TripService.Domain.Repositories.Interfaces;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.ModelBinding;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Diagnostics.CodeAnalysis;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.TripService.API.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class TripController : ControllerBase
    {
        private readonly ILogger<TripController> logger;
        private readonly ITripRepository tripRepository;
        private readonly IMapper mapper;

        public TripController(ILogger<TripController> logger, ITripRepository tripRepository, IMapper mapper)
        {
            this.logger = logger;
            this.tripRepository = tripRepository;
            this.mapper = mapper;
        }

        /// <summary>
        /// Create Trip
        /// </summary>
        /// <param name="userId">userId</param>
        /// <param name="tripDto">tripDto</param>
        /// <returns>tripId</returns>
        [HttpPost("trip")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<string>> CreateTrip([FromBody] TripRequestDto tripDto)
        {
            try
            {
                logger.LogInformation($"Create Trip");
                var trip = mapper.Map<Trips>(tripDto);
                trip.Id = ApplicationUtils.RandomNumber();
                var result = await tripRepository.SaveTrip(trip);
                logger.LogInformation($"trip created sucessfully for {result.Id}");
                return new OkObjectResult(result.Id);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Creating trip failed with an exception.");
                return ApplicationUtils.ReturnFailureResult(StatusCodes.Status500InternalServerError);
            }
        }

        /// <summary>
        /// Get Trip by Trip Id
        /// </summary>
        /// <param name="tripId">TripId</param>
        /// <returns>Trip Object</returns>
        [HttpGet("trip/{tripId}")]
        [ProducesResponseType(StatusCodes.Status200OK)]
        [ProducesResponseType(StatusCodes.Status400BadRequest)]
        [ProducesResponseType(StatusCodes.Status500InternalServerError)]
        public async Task<ActionResult<Trips>> GetTrip([FromRoute, BindRequired, NotNull, Required] string tripId)
        {
            try
            {
                logger.LogInformation($"Get trip tripId {tripId}");
                if (string.IsNullOrWhiteSpace(tripId))
                {
                    return ApplicationUtils.ReturnNotFoundObjectResult("Trip not found");
                }

                var result = await tripRepository.GetTrip(tripId);
                if (result == null)

                {
                    return ApplicationUtils.ReturnNotFoundObjectResult($"Trip Id {tripId} is not found");
                }

                result.MinSpeed = GetSpeed(result.DeviceEvents, "Min");
                result.MaxSpeed = GetSpeed(result.DeviceEvents, "Max");
                result.AverageSpeed = GetSpeed(result.DeviceEvents, "Avg");

                return new OkObjectResult(result);
            }
            catch (Exception ex)
            {
                logger.LogError(ex, "Creating trip failed with an exception.");
                return ApplicationUtils.ReturnFailureResult(StatusCodes.Status500InternalServerError);
            }
        }

        private double GetSpeed(List<DeviceEvent> deviceEvents, string condition)
        {
            if (deviceEvents != null)
            {
                switch (condition)
                {
                    case "Min":
                        return deviceEvents.Select(o => o.Speed).Min();
                    case "Max":
                        return deviceEvents.Select(o => o.Speed).Max();
                    case "Avg":
                        return deviceEvents.Select(o => o.Speed).Average();
                }
            }
            return 0.0;
        }
    }
}
