﻿using AutoMapper;
using Demo.TripService.API.Models;
using Demo.TripService.Domain.Models;

namespace Demo.TripService.API.MappingConfigurations
{
    public class AutoMapperProfile: Profile
    {
        public AutoMapperProfile()
        {
            CreateMap<TripRequestDto, Trips>().ReverseMap();
            CreateMap<GeoCoordinateDto, GeoCoordinate>().ReverseMap();
            CreateMap<GeoAddressDto, GeoAddress>().ReverseMap();
            CreateMap<GeoAddressDto, GeoAddress>().ReverseMap();
            CreateMap<GeoLocationDto, GeoLocation>().ReverseMap();
        }
    }
}
