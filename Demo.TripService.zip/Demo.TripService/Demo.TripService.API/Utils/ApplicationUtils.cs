﻿using Demo.TripService.Domain.Models;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Demo.TripService.API.Utils
{
    public class ApplicationUtils
    {
        private static readonly Random random = new Random();
        public static ActionResult ReturnNotFoundObjectResult(string message)
        {
            return new NotFoundObjectResult(new ProblemDetails
            {
                Title = ErrorCode.NotFound.Title,
                Detail = message,
                Status = ErrorCode.NotFound.Code
            });
        }

        public static ActionResult ReturnBadRequestObjectResult(string message)
        {
            return new BadRequestObjectResult(new ProblemDetails
            {
                Title = ErrorCode.BadRequest.Title,
                Detail = message,
                Status = ErrorCode.BadRequest.Code
            });
        }

        public static ActionResult ReturnFailureResult(int statusCode)
        {
            var responseError = new ProblemDetails
            {
                Title = ErrorCode.InternalServerError.Title,
                Detail = "Failed to perform operation. Please try again and connect support team if problem remain persists",
                Status = ErrorCode.InternalServerError.Code
            };

            return new ObjectResult(responseError)
            {
                StatusCode = statusCode
            };
        }

        public static ActionResult ReturnUnauthorizedResult(IDictionary<string, string[]> validationErrors)
        {
            return new UnauthorizedObjectResult(new ValidationProblemDetails(validationErrors)
            {
                Title = ErrorCode.UnAuthorized.Title,
                Status = ErrorCode.UnAuthorized.Code
            });
        }

        public static string RandomNumber()
        {
            const string chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            return new string(Enumerable.Repeat(chars, 9)
                .Select(s => s[random.Next(s.Length)]).ToArray());
        }
    }
}
